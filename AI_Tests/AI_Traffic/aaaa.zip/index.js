process.env.TF_CPP_MIN_LOG_LEVEL = '2'; // 0=all, 1=info, 2=warning, 3=error
import * as tf from "@tensorflow/tfjs-node";

// Training params
const TOTAL_SAMPLES = 1_000_000;
const BATCH_SIZE = 256;
const STEPS_PER_EPOCH = 10_000;
const EPOCHS = 20;

// Normalization constants
const MEAN = tf.tensor([1500.0, 50.5, 450.0, 100.0, 0.5]);
const STD = tf.tensor([866.0254, 28.866, 230.94, 57.735, 0.288675]);

// Data generator
function* genBatch(batchSize) {
  while (true) {
    const reqPerSec = tf.randomUniform([batchSize], 0, 3000);
    const uniqueIPs = tf.randomUniform([batchSize], 1, 101);
    const avgHeaderSize = tf.randomUniform([batchSize], 50, 850);
    const failedRequests = tf.randomUniform([batchSize], 0, 200);
    const burstiness = tf.randomUniform([batchSize], 0, 1);

    const X = tf.stack([reqPerSec, uniqueIPs, avgHeaderSize, failedRequests, burstiness], 1);

    const Y = tf.tidy(() => {
      const cond1 = reqPerSec.greater(1200);
      const cond2 = uniqueIPs.greater(10).logicalAnd(reqPerSec.greater(900));
      const cond3 = burstiness.greater(0.8).logicalAnd(failedRequests.greater(80));
      return cond1.logicalOr(cond2).logicalOr(cond3).cast("float32").reshape([batchSize, 1]);
    });

    const Xnorm = X.sub(MEAN).div(STD);
    yield { xs: Xnorm, ys: Y };
  }
}

// Create model
const model = tf.sequential();
model.add(tf.layers.dense({ units: 64, activation: "relu", inputShape: [5] }));
model.add(tf.layers.dropout({ rate: 0.3 }));
model.add(tf.layers.dense({ units: 32, activation: "relu" }));
model.add(tf.layers.dropout({ rate: 0.3 }));
model.add(tf.layers.dense({ units: 16, activation: "relu" }));
model.add(tf.layers.dense({ units: 1, activation: "sigmoid" }));

model.compile({
  optimizer: tf.train.adam(0.0005),
  loss: "binaryCrossentropy",
  metrics: ["accuracy"],
});

console.log("Starting training...");

const dataset = tf.data.generator(() => genBatch(BATCH_SIZE))
  .take(STEPS_PER_EPOCH * EPOCHS)
  .batch(1);

await model.fitDataset(dataset, {
  epochs: EPOCHS,
  batchesPerEpoch: STEPS_PER_EPOCH,
  verbose: 1,
});

await model.save("file://./ddos_model_tfjs");
console.log("Saved model to ./ddos_model_tfjs");
