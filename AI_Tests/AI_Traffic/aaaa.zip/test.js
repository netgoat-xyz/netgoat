import * as tf from "@tensorflow/tfjs-node";
import readline from "readline";
import fs from "fs";

const MODEL_PATH = process.env.MODEL_PATH || "file://./ddos_model_tfjs/model.json";
const MEAN = tf.tensor([1500.0, 50.5, 450.0, 100.0, 0.5]);
const STD  = tf.tensor([866.0254, 28.866, 230.94, 57.735, 0.288675]);
const UAs = ["Chrome","Firefox","Edge","Safari","Bot","curl","Postman","Python-requests","Android"];

function randomIP(){ return `${Math.floor(Math.random()*256)}.${Math.floor(Math.random()*256)}.${Math.floor(Math.random()*256)}.${Math.floor(Math.random()*256)}`; }
function genSample(){ return { reqPerSec: Math.random()*3000, uniqueIPs: 1 + Math.floor(Math.random()*100), avgHeaderSize: 50 + Math.random()*800, failedRequests: Math.random()*200, burstiness: Math.random(), ip: randomIP(), ua: UAs[Math.floor(Math.random()*UAs.length)] }; }
async function samplePredict(model, s){ return tf.tidy(()=>{ const X = tf.tensor2d([[s.reqPerSec, s.uniqueIPs, s.avgHeaderSize, s.failedRequests, s.burstiness]]); const Xn = X.sub(MEAN).div(STD); return model.predict(Xn).dataSync()[0]; }); }
function colorize(pct){ if(pct>=0.8) return `\x1b[41m${(pct*100).toFixed(1)}%\x1b[0m`; if(pct>=0.5) return `\x1b[43m${(pct*100).toFixed(1)}%\x1b[0m`; return `\x1b[42m${(pct*100).toFixed(1)}%\x1b[0m`; }

async function main(){
  const model = await tf.loadLayersModel(MODEL_PATH);
  console.log("Model loaded from", MODEL_PATH);
  let running = false, rateMs = 500, threshold = 0.5, intervalHandle = null;
  let total = 0, flagged = 0;
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, prompt: "cmd> " });

  async function emitOnce(){
    const s = genSample();
    const p = await samplePredict(model, s);
    total++; if(p>=threshold) flagged++;
    const tag = p>=threshold ? "FLAG" : "OK  ";
    console.log(`${new Date().toISOString()} | ${tag} | prob=${colorize(p)} | ip=${s.ip} ua=${s.ua} rps=${s.reqPerSec.toFixed(1)} uniq=${s.uniqueIPs} fail=${s.failedRequests.toFixed(1)} burst=${s.burstiness.toFixed(2)}`);
  }

  function startStream(){ if(running) return console.log("already running"); running = true; intervalHandle = setInterval(()=> emitOnce().catch(e=>console.error("pred err",e)), Math.max(10, rateMs)); console.log("stream started @", Math.round(1000/rateMs), "events/sec"); }
  function stopStream(){ if(!running) return console.log("not running"); running = false; clearInterval(intervalHandle); intervalHandle = null; console.log("stream stopped"); }

  async function executeCommand(line, silent=false){
    const parts = line.trim().split(/\s+/);
    const cmd = parts[0];
    if(cmd==="") return;
    if(cmd==="exit"||cmd==="quit"){ stopStream(); rl.close(); return; }
    if(cmd==="run"){ await emitOnce(); if(!silent) rl.prompt(); return; }
    if(cmd==="start"){ startStream(); if(!silent) rl.prompt(); return; }
    if(cmd==="stop"){ stopStream(); if(!silent) rl.prompt(); return; }
    if(cmd==="rate"){ const v = Number(parts[1]); if(Number.isFinite(v) && v>0){ rateMs = Math.max(10, Math.floor(1000/v)); if(running){ stopStream(); startStream(); } console.log("rate set to", v, "events/sec"); } else console.log("usage: rate <eventsPerSecond>"); if(!silent) rl.prompt(); return; }
    if(cmd==="interval"){ const v = Number(parts[1]); if(Number.isFinite(v) && v>=10){ rateMs = v; if(running){ stopStream(); startStream(); } console.log("interval set to", rateMs, "ms"); } else console.log("usage: interval <ms> (>=10)"); if(!silent) rl.prompt(); return; }
    if(cmd==="threshold"){ const v = Number(parts[1]); if(Number.isFinite(v) && v>=0 && v<=1){ threshold = v; console.log("threshold =", threshold); } else console.log("usage: threshold <0..1>"); if(!silent) rl.prompt(); return; }
    if(cmd==="stats"){ console.log(`total=${total} flagged=${flagged} flagged%=${total?((flagged/total)*100).toFixed(2):"0.00"}`); if(!silent) rl.prompt(); return; }
    if(cmd==="help"||cmd==="?"){ console.log(`commands: run start stop rate <ev/sec> interval <ms> threshold <0..1> stats exit schedule <expr> loadscript <file> help`); if(!silent) rl.prompt(); return; }
    if(cmd==="loadscript"){ const path = parts.slice(1).join(" "); try{ const txt = await fs.promises.readFile(path,"utf8"); await runScheduleString(txt); }catch(e){ console.error("load error",e); } if(!silent) rl.prompt(); return; }
    if(cmd==="schedule"){ const expr = line.slice(line.indexOf(" ")+1); if(!expr) console.log("usage: schedule <spec>"); else await runScheduleString(expr); if(!silent) rl.prompt(); return; }
    console.log("unknown command, try 'help'"); if(!silent) rl.prompt();
  }

  async function runScheduleString(spec){
    const tasks = [];
    const entries = spec.split(";").map(s=>s.trim()).filter(Boolean);
    for(const e of entries){
      let m = e.match(/^(\+?\d+):(.+)$/);
      if(m){
        const t = Number(m[1]);
        const cmd = m[2].trim();
        tasks.push({delay: t*1000, cmd});
        continue;
      }
      m = e.match(/^at\s+(\d+):(.+)$/i);
      if(m){
        const t = Number(m[1]);
        tasks.push({delay: t*1000, cmd: m[2].trim()});
        continue;
      }
      tasks.push({delay: 0, cmd: e});
    }
    const startTs = Date.now();
    const timers = [];
    for(const t of tasks){
      const to = setTimeout(()=>{ executeCommand(t.cmd, true).catch(console.error); }, t.delay);
      timers.push(to);
    }
    console.log("scheduled", tasks.length, "tasks from now");
    return new Promise((resolve)=>{ setTimeout(()=>{ clearScheduled(timers); resolve(); }, Math.max(0, Math.max(...tasks.map(x=>x.delay))+1000)); });
  }

  function clearScheduled(timers){ for(const id of timers) clearTimeout(id); }

  rl.on("line", async (l)=>{ try{ await executeCommand(l); }catch(e){ console.error(e); rl.prompt(); } });
  rl.prompt();
}

main().catch(e=>{ console.error(e); process.exit(1); });
