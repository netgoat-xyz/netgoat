# electionRaft
Just a simple basic raft algorithm to pick a leader
