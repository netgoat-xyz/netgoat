import { mdxAnnotations } from 'mdx-annotations'

export const recmaPlugins = [mdxAnnotations.recma]
